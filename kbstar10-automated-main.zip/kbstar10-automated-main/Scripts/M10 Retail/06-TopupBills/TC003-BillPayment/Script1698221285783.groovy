import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

Mobile.println(TC_id)

Mobile.println(note)

WebUI.callTestCase(findTestCase('Test Cases/M10 Retail/01-Login/TC001-Login'), [('email_address') : email_address, ('password') : password],
	FailureHandling.OPTIONAL)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR01-Menu'), 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR02-SearchAllfeature'), 0)

Mobile.delay(3)

Mobile.setText(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR02-SearchAllfeature'), 'top', 0)

Mobile.delay(3)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR15-TopupMenu'), 0)

if (payment_method == 'PLN Postpaid') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR01-PLNPostpaidiMenu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR08-InputAccountNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR08-InputAccountNumber'), number, 0)
	
	Mobile.pressBack()
	
	Mobile.delay(4)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)
	
	Mobile.delay(4)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR09-ConfirmButton'), 0)
	
	for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
	
	Mobile.delay(3)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
	
	
} else if (payment_method == 'Internet TV') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR02-InternetAndTVMenu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR08-InputAccountNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR08-InputAccountNumber'), number, 0)
	
	Mobile.pressBack()
	
	Mobile.delay(4)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)
	
	Mobile.delay(4)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR09-ConfirmButton'), 0)
	
	for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
	
	Mobile.delay(3)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
	
	
} else if (payment_method == 'Mobile Postpaid') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/Mobile Postpaid Menu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR08-InputAccountNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR08-InputAccountNumber'), number, 0)
	
	Mobile.pressBack()
	
	Mobile.delay(4)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)
	
	Mobile.delay(4)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR09-ConfirmButton'), 0)
	
	for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
	
	Mobile.delay(3)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
	
	
} else if (payment_method == 'Credit Card') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/CreditCardMenu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR01-ChooseBankName'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR02-KBBukopin'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR05-InputCardNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR05-InputCardNumber'), number, 0)
	
	Mobile.pressBack()
	
	Mobile.delay(4)
	
	if (Mobile.verifyElementVisible(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)){
		
		Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)
		
		Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR06-InoutBillAmount'), 0)
		
		Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR06-InoutBillAmount'), '100000', 0)
		
		Mobile.pressBack()
		
		Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR07-ButtonNext'), 0)
		
		Mobile.delay(4)
		
		Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR08-ConfirmButton'), 0)
		
		for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
		
		Mobile.delay(3)
		
		Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
		
	} else {
		
		println('Response System Error')
	}
	

} else if (payment_method == 'BPJS') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/BPJS Menu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/BPJS/OR01-InputBPJSNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/BPJS/OR01-InputBPJSNumber'), number, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/BPJS/OR02-ChooseMonth'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/BPJS/OR03-1Month'), 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/BPJS/OR10-NextButton'), 0)
	
	Mobile.delay(3)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/Credit Card/OR08-ConfirmButton'), 0)
		
	for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
		
	Mobile.delay(3)
		
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
	
	
} else if (payment_method == 'Taxes'){
	
	
	
} else if(payment_method == 'Phone Bill') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/Phone Bill Menu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR08-InputAccountNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR08-InputAccountNumber'), number, 0)
	
	Mobile.pressBack()
	
	Mobile.delay(4)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)
	
	Mobile.delay(4)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/PLN Postpaid/OR09-ConfirmButton'), 0)
	
	for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
	
	Mobile.delay(3)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
	
}

Mobile.println(message)

Mobile.delay(3)