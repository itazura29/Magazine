import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

Mobile.println(TC_id)

Mobile.println(note)

WebUI.callTestCase(findTestCase('Test Cases/M10 Retail/01-Login/TC001-Login'), [('email_address') : email_address, ('password') : password],
	FailureHandling.OPTIONAL)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR01-Menu'), 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR02-SearchAllfeature'), 0)

Mobile.setText(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR02-SearchAllfeature'), 'top', 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR15-TopupMenu'), 0)

if (payment_method == 'Gopay') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR01-GopayMenu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR04-InputPhoneNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR04-InputPhoneNumber'), phone_number, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)
	
	Mobile.delay(2)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR06-Rp20000'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR16-ButtonNextAfterAmount'), 0)
	
	Mobile.delay(2)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR11-ButtonConfirm'), 0)
	
	for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
	
	Mobile.delay(3)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
	
}else if (payment_method == 'Ovo') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR02-OvoMenu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR04-InputPhoneNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR04-InputPhoneNumber'), phone_number, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)
	
	Mobile.delay(2)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR06-Rp20000'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR16-ButtonNextAfterAmount'), 0)
	
	Mobile.delay(2)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR11-ButtonConfirm'), 0)
	
	for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
	
	Mobile.delay(3)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
	
}else if (payment_method == 'LinkAja') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR03-LinkAjaMenu'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR04-InputPhoneNumber'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR04-InputPhoneNumber'), phone_number, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR-ButtonNext'), 0)
	
	Mobile.delay(2)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR06-Rp20000'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR16-ButtonNextAfterAmount'), 0)
	
	Mobile.delay(2)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR11-ButtonConfirm'), 0)
	
	for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)}
	
	Mobile.delay(3)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR14-BacktoHomapage'), 0)
}

Mobile.println(message)

Mobile.delay(3)