import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

Mobile.println(TC_id)

Mobile.println(note)

WebUI.callTestCase(findTestCase('Test Cases/M10 Retail/01-Login/TC001-Login'), [('email_address') : email_address, ('password') : password],
	FailureHandling.OPTIONAL)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR01-Menu'), 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR02-SearchAllfeature'), 0)

Mobile.setText(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR02-SearchAllfeature'), 'planning',
	0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/07-PlanningAccount/Topup and Withdraw Planning/List'), 0)

Mobile.delay(2)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/07-PlanningAccount/Topup and Withdraw Planning/OR09-DataListPlanning'),
	0)

Mobile.delay(2)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/07-PlanningAccount/Topup and Withdraw Planning/OR03-Withdrawal'), 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/07-PlanningAccount/Topup and Withdraw Planning/OR06-TopupAmount'),
	0)

Mobile.setText(findTestObject('Object Repository/M10 Object Repository/07-PlanningAccount/Topup and Withdraw Planning/OR06-TopupAmount'),
	withdrawal_amount, 0)

Mobile.pressBack()

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/07-PlanningAccount/Topup and Withdraw Planning/OR07-ButtonNext'),
	0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/07-PlanningAccount/Topup and Withdraw Planning/OR08-ButtonConfirm'),
	0)

for (def index : (0..5)) {
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/06-Topup/OR12-1'), 0)
}

Mobile.delay(3)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/07-PlanningAccount/Topup and Withdraw Planning/OR10-BackToHomePage'), 0)