import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import groovy.time.TimeCategory as TimeCategory

Mobile.println(TC_id)

Mobile.println(note)

Date todaysDate = new Date();

def setDateToday = todaysDate.format("MMddyyyy");

def setDateToday1W = todaysDate + 1

setDateToday1W = setDateToday1W.format("MMddyyyy")

WebUI.callTestCase(findTestCase('Test Cases/M10 Retail/01-Login/TC001-Login'), [('email_address') : email_address, ('password') : password],
	FailureHandling.OPTIONAL)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR01-Menu'), 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR02-SearchAllfeature'), 0)

Mobile.setText(findTestObject('Object Repository/M10 Object Repository/02-ForeignExchange/OR02-SearchAllfeature'), 'plus', 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR01-PlusAccountMenu'), 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR02-InputAccountName'), 0)

Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR02-InputAccountName'), accountName, 0)

Mobile.pressBack()

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)

if(setMethod == 'setInitialDeposit') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR04-SetInitialDeposit'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR06-EditDepositAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR06-EditDepositAmount'), depositAmount, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)
	
	
}else if(setMethod == 'setSchedulerByDate'){
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR05-SetScheduler'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR12-StartDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR14-EditDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), setDateToday, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR16-ApplyButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR17-EndDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR14-EditDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'),setDateToday1W, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR16-ApplyButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR18-Frequency'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR19-Daily'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR20-DeductionAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR20-DeductionAmount'), deductionAmount, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR21-NextButton'), 0)
		
	
}else if(setMethod == 'setSchedulerByAmount') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR05-SetScheduler'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR22-SwitchAmount'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR23-GoalAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR23-GoalAmount'), goalAmount, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR24-StartDateAmount'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR14-EditDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), setDateToday, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR16-ApplyButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR25-FrequencAmount'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR26-DailyAmount'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/DeductionAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/DeductionAmount'), deductionAmount, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR21-NextButton'), 0)
		
}else if(setMethod == 'setInitialSchedulerByDate') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR04-SetInitialDeposit'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/SetScheduler'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR06-EditDepositAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR06-EditDepositAmount'), depositAmount, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR12-StartDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR14-EditDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), setDateToday, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR16-ApplyButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR17-EndDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR14-EditDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'),setDateToday1W, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR16-ApplyButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR18-Frequency'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR19-Daily'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR20-DeductionAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR20-DeductionAmount'), deductionAmount, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR21-NextButton'), 0)
	
}else if (setMethod == 'setInitialSchedulerByAmount') {
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR04-SetInitialDeposit'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/SetScheduler'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR06-EditDepositAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR06-EditDepositAmount'), depositAmount, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR03-NextButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR22-SwitchAmount'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR23-GoalAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR23-GoalAmount'), goalAmount, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR24-StartDateAmount'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR14-EditDate'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR15-InputDate'), setDateToday, 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR16-ApplyButton'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR25-FrequencAmount'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR26-DailyAmount'), 0)
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/DeductionAmount'), 0)
	
	Mobile.setText(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/DeductionAmount'), deductionAmount, 0)
	
	Mobile.pressBack()
	
	Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR21-NextButton'), 0)
}


Mobile.delay(3)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/Checkbox Tnc'), 0)

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR08-ConfirmButton'), 0)

for (def index : (0..5)) { Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR09-1'), 0)
	
}

Mobile.delay(3)

if (Mobile.verifyElementVisible(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR10-GotoPlusAccountPage'), 0)) {
	
	Mobile.println(message)
}

Mobile.tap(findTestObject('Object Repository/M10 Object Repository/05-PlusAccount/OR10-GotoPlusAccountPage'), 0)